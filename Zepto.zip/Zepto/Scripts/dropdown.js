// document.addEventListener("DOMContentLoaded", function() {var dropval = document.getElementById("dvSites");
// dropval.style.visibility = "hidden";
// dropval.style.height = "0px";
// dropval.style.transitionProperty = "height";
// dropval.style.transitionDuration = "2s";
// var drop = document.getElementById("dvss");
// drop.style.visibility = "hidden";
// drop.style.height = "0px";
// drop.style.transitionProperty = "height";
// drop.style.transitionDuration = "2s";
//     function navFun(value){
//     if (value ==="dvSites"){
//     dropval.style.height = "300px";
//     if(dropval.style.visibility === "visible"){
//          dropval.style.height = "0px";
//         dropval.style.transitionDuration = "2s";
//         dropval.style.transitionProperty = "height";
//        dropval.style.visibility = "hidden";
//     }else{
//         dropval.style.visibility = "visible";
//     }   
// }else{
//     drop.style.height = "300px";
//     if(drop.style.visibility === "visible"){
//          drop.style.height = "0px";
//         drop.style.transitionDuration = "2s";
//         drop.style.transitionProperty = "height";
//        drop.style.visibility = "hidden";
//     }else{
//         drop.style.visibility = "visible";
//     }   

//     }  
// }

// document.querySelector('#btnShow').addEventListener('click', () => { navFun('dvSites') });
// document.querySelector('#btnss').addEventListener('click', () => {navFun('dvss')});

// });


